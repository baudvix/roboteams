#from naoqi import ALProxy
#memoryProxy = ALProxy("ALMemory", "194.95.174.188", 9559)
#arrayOfMarker = memoryProxy.getData("LandmarkDetected")
#print arrayOfMarker


def printAndSayMessage(message):
    print message

printAndSayMessage(str(1)+"asldkfj"+str(2))